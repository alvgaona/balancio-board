In OrCAD Capture, select File > Import Design, then the EDIF tab. Open the .edf file and save the .DSN design.
In Allegro, select File > Import > Logic > "Other". Select the .tel file. Set the device path to devices.
Then select File > Import > IDF and select the .emn and .emp files.
To create an editable Allegro board, select File > Import > CAD Translators > PADS and select the .asc file.
Use the default pads_in.ini file. Check the layer mapping, review the board, and save it as a .brd file.
The PADS board includes copper and footprint geometry. Flux does not include Allegro .psm or .dra files or .olb symbol libraries.
Package names are Flux footprint names. Map each package to an Allegro footprint in PSMPATH.